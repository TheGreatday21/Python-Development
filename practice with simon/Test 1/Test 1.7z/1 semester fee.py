course= int(input("\nHow many years is your course taking :\t"))
sem = course *2
print(f"\nYour course has {sem} semesters in it \n")
fee_persem = 1500000
print(f"Your paying {fee_persem} per semester\n")
tuition = sem *fee_persem
print(f"Your total tuition at the end of your course is going to be {tuition}")
print("\n\nDont forget to read smart and hard\n\n")












