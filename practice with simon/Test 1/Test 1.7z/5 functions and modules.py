
def write_student_info():
    name = input("What is your name ")
    age = input("What is your age ")
write_student_info()
student_info = write.(write_student_info)

with.open("student_info","r")













