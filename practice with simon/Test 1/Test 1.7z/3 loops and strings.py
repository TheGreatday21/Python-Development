#This program will generate studenyt ids
#creating a for loop

for num in range(1,11):
    print(f"Student id : UCU1000{num}\n")
#The loop will run till it reaches  the set parameter of 10














