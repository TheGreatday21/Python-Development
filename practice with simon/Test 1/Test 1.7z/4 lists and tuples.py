
faculty = { ('Engineering'),('Bussiness'),('Journalism')}
Engineering = {('civil','electric','automotive')}
Journalism = {('articles','field work','presenting')}
Bussiness = {('marketting','real estate','investments')}
























